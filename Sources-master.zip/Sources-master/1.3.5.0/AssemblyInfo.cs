﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyFileVersion("1.3.5")]
[assembly: Guid("f571b16a-2c9b-44ab-b115-7c762c9e4e7e")]
[assembly: Extension]
[assembly: AssemblyTitle("Terraria")]
[assembly: AssemblyProduct("Terraria")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("Re-Logic")]
[assembly: AssemblyCopyright("Copyright © Re-Logic 2017")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.3.5.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
