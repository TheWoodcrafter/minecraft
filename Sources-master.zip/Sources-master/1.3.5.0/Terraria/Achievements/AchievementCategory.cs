﻿// Decompiled with JetBrains decompiler
// Type: Terraria.Achievements.AchievementCategory
// Assembly: TerrariaServer, Version=1.3.5.0, Culture=neutral, PublicKeyToken=null
// MVID: 13381DB9-8FD8-4EBB-8CED-9CF82DC89291
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Terraria\TerrariaServer.exe

namespace Terraria.Achievements
{
  public enum AchievementCategory
  {
    None = -1,
    Slayer = 0,
    Collector = 1,
    Explorer = 2,
    Challenger = 3,
  }
}
