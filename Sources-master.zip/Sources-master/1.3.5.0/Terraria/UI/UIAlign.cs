﻿// Decompiled with JetBrains decompiler
// Type: Terraria.UI.UIAlign
// Assembly: TerrariaServer, Version=1.3.5.0, Culture=neutral, PublicKeyToken=null
// MVID: 13381DB9-8FD8-4EBB-8CED-9CF82DC89291
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Terraria\TerrariaServer.exe

namespace Terraria.UI
{
  public static class UIAlign
  {
    public const float Left = 0.0f;
    public const float Center = 0.5f;
    public const float Right = 1f;
    public const float Top = 0.0f;
    public const float Middle = 0.5f;
    public const float Bottom = 1f;
  }
}
