﻿// Decompiled with JetBrains decompiler
// Type: Terraria.ID.TileEntityID
// Assembly: TerrariaServer, Version=1.3.5.0, Culture=neutral, PublicKeyToken=null
// MVID: 13381DB9-8FD8-4EBB-8CED-9CF82DC89291
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Terraria\TerrariaServer.exe

namespace Terraria.ID
{
  public class TileEntityID
  {
    public const byte TrainingDummy = 0;
    public const byte ItemFrame = 1;
    public const byte LogicSensor = 2;
  }
}
