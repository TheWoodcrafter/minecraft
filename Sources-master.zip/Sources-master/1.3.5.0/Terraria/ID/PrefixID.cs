﻿// Decompiled with JetBrains decompiler
// Type: Terraria.ID.PrefixID
// Assembly: TerrariaServer, Version=1.3.5.0, Culture=neutral, PublicKeyToken=null
// MVID: 13381DB9-8FD8-4EBB-8CED-9CF82DC89291
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Terraria\TerrariaServer.exe

namespace Terraria.ID
{
  public class PrefixID
  {
    public const int Large = 1;
    public const int Massive = 2;
    public const int Dangerous = 3;
    public const int Savage = 4;
    public const int Sharp = 5;
    public const int Pointy = 6;
    public const int Tiny = 7;
    public const int Terrible = 8;
    public const int Small = 9;
    public const int Dull = 10;
    public const int Unhappy = 11;
    public const int Bulky = 12;
    public const int Shameful = 13;
    public const int Heavy = 14;
    public const int Light = 15;
    public const int Sighted = 16;
    public const int Rapid = 17;
    public const int Hasty = 18;
    public const int Intimidating = 19;
    public const int Deadly = 20;
    public const int Staunch = 21;
    public const int Awful = 22;
    public const int Lethargic = 23;
    public const int Awkward = 24;
    public const int Powerful = 25;
    public const int Mystic = 26;
    public const int Adept = 27;
    public const int Masterful = 28;
    public const int Inept = 29;
    public const int Ignorant = 30;
    public const int Deranged = 31;
    public const int Intense = 32;
    public const int Taboo = 33;
    public const int Celestial = 34;
    public const int Furious = 35;
    public const int Keen = 36;
    public const int Superior = 37;
    public const int Forceful = 38;
    public const int Broken = 39;
    public const int Damaged = 40;
    public const int Shoddy = 41;
    public const int Quick = 42;
    public const int Deadly2 = 43;
    public const int Agile = 44;
    public const int Nimble = 45;
    public const int Murderous = 46;
    public const int Slow = 47;
    public const int Sluggish = 48;
    public const int Lazy = 49;
    public const int Annoying = 50;
    public const int Nasty = 51;
    public const int Manic = 52;
    public const int Hurtful = 53;
    public const int Strong = 54;
    public const int Unpleasant = 55;
    public const int Weak = 56;
    public const int Ruthless = 57;
    public const int Frenzying = 58;
    public const int Godly = 59;
    public const int Demonic = 60;
    public const int Zealous = 61;
    public const int Hard = 62;
    public const int Guarding = 63;
    public const int Armored = 64;
    public const int Warding = 65;
    public const int Arcane = 66;
    public const int Precise = 67;
    public const int Lucky = 68;
    public const int Jagged = 69;
    public const int Spiked = 70;
    public const int Angry = 71;
    public const int Menacing = 72;
    public const int Brisk = 73;
    public const int Fleeting = 74;
    public const int Hasty2 = 75;
    public const int Quick2 = 76;
    public const int Wild = 77;
    public const int Rash = 78;
    public const int Intrepid = 79;
    public const int Violent = 80;
    public const int Legendary = 81;
    public const int Unreal = 82;
    public const int Mythical = 83;
    public const int Count = 84;
  }
}
