﻿// Decompiled with JetBrains decompiler
// Type: Terraria.ID.PlayerTextureID
// Assembly: TerrariaServer, Version=1.3.5.0, Culture=neutral, PublicKeyToken=null
// MVID: 13381DB9-8FD8-4EBB-8CED-9CF82DC89291
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Terraria\TerrariaServer.exe

namespace Terraria.ID
{
  public static class PlayerTextureID
  {
    public const int Head = 0;
    public const int EyeWhites = 1;
    public const int Eyes = 2;
    public const int TorsoSkin = 3;
    public const int Undershirt = 4;
    public const int Hands = 5;
    public const int Shirt = 6;
    public const int ArmSkin = 7;
    public const int ArmUndershirt = 8;
    public const int ArmHand = 9;
    public const int LegSkin = 10;
    public const int Pants = 11;
    public const int Shoes = 12;
    public const int ArmShirt = 13;
    public const int Extra = 14;
    public const int Count = 15;
  }
}
