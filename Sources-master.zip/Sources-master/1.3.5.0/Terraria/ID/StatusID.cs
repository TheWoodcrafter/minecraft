﻿// Decompiled with JetBrains decompiler
// Type: Terraria.ID.StatusID
// Assembly: TerrariaServer, Version=1.3.5.0, Culture=neutral, PublicKeyToken=null
// MVID: 13381DB9-8FD8-4EBB-8CED-9CF82DC89291
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Terraria\TerrariaServer.exe

namespace Terraria.ID
{
  public class StatusID
  {
    public const int Ok = 0;
    public const int LaterVersion = 1;
    public const int UnknownError = 2;
    public const int EmptyFile = 3;
    public const int DecryptionError = 4;
    public const int BadSectionPointer = 5;
    public const int BadFooter = 6;
  }
}
