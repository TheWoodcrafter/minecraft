﻿// Decompiled with JetBrains decompiler
// Type: Terraria.ID.RecipeGroupID
// Assembly: TerrariaServer, Version=1.3.5.0, Culture=neutral, PublicKeyToken=null
// MVID: 13381DB9-8FD8-4EBB-8CED-9CF82DC89291
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Terraria\TerrariaServer.exe

namespace Terraria.ID
{
  public class RecipeGroupID
  {
    public static int Birds = 0;
    public static int Scorpions = 1;
    public static int Bugs = 2;
    public static int Ducks = 3;
    public static int Squirrels = 4;
    public static int Butterflies = 5;
    public static int Fireflies = 6;
    public static int Snails = 7;
  }
}
