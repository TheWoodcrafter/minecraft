﻿// Decompiled with JetBrains decompiler
// Type: Terraria.Net.Sockets.SocketReceiveCallback
// Assembly: TerrariaServer, Version=1.3.5.0, Culture=neutral, PublicKeyToken=null
// MVID: 13381DB9-8FD8-4EBB-8CED-9CF82DC89291
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Terraria\TerrariaServer.exe

namespace Terraria.Net.Sockets
{
  public delegate void SocketReceiveCallback(object state, int size);
}
