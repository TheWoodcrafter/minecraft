﻿// Decompiled with JetBrains decompiler
// Type: Terraria.PartyHatColor
// Assembly: TerrariaServer, Version=1.3.5.0, Culture=neutral, PublicKeyToken=null
// MVID: 13381DB9-8FD8-4EBB-8CED-9CF82DC89291
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Terraria\TerrariaServer.exe

namespace Terraria
{
  public enum PartyHatColor
  {
    None = 0,
    Blue = 1,
    Pink = 2,
    Cyan = 3,
    Purple = 4,
    Count = 5,
    White = 5,
  }
}
